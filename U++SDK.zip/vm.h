#pragma once
#include <cstdlib> 
#include <conio.h>
#include "eval.h"
extern bool f; 
namespace vm {
    vector<string> lines;
    void clear(string &s) {
        //����ͷβ�ո�
        while (s.size() && s.back() == ' ')s.pop_back();
        reverse(s.begin(), s.end());
        while (s.size() && s.back() == ' ')s.pop_back();
        reverse(s.begin(), s.end());
    }
    int cur = 0;
    map<int, int>jmp;
    void parser_while(string s);
    void parser_if(string s);
    void parser_print(string s);
    void parser_scanf(string s);
    void parser_putchar(string s);
    void parser_end(string s);// ���� '}'
    void parser_map(string s);
    void parser_gets(string s);
	void run(string s); 
    
    void cal_jmp();
    void parser(string s) {
    	if (s[0]=='#')
    	{
    		cur++;
    		return;
		}//���Ե�ע�͹��� 
/*		if(s.find("%import") != s.npos)
		{
			ifstream ff((eval::Expression(s.substr(7, s.length() - 7)).STR_VAL).c_str());
    		stringstream fff; 
			fff << ff.rdbuf();
    		vm::run(fff.str());
    		cur++;
		}
        else */if (s.find("while") != s.npos) parser_while(s);
        else if (s.find("if") != s.npos) parser_if(s);
        else if (s.find("input") != s.npos) parser_scanf(s);
        else if (s.find("gets") != s.npos)parser_gets(s);
        else if (s.find("print") != s.npos)parser_print(s);
        else if (s.find("endl")!=s.npos)
        {
        	cout<<endl;
        	cur++;
		}
        else if (s.find("getchar")!=s.npos)
		{
			string kkkk="";
			kkkk+=cin.get();
			eval::Expression(s.substr(7, s.length() - 7) + string(" = \'") + kkkk + string("\'"));
			cur++;
		} 
        else if (s.find("putchar") != s.npos)parser_putchar(s);
        else if (count(s.begin(), s.end(), '}'))parser_end(s);
        else if (s.find("map") != s.npos)parser_map(s);
        else if (s.find("system") != s.npos)
        {
        	string k=s.substr(6,s.length()-6),bf="";
        	if(k[0]=='"'&&k[k.size()-1]=='"')
        	{
        		bf=k.substr(1,k.size()-1);
			}
			else
			{
				bf=eval::Expression(s.substr(6, s.length() - 6)).STR_VAL;
			}
        	system(bf.c_str());
        	cur++; 
		}
		else if(s.find("eval")!=s.npos)
		{
			vm::run(eval::Expression(s.substr(4, s.length() - 4)).STR_VAL);
			cur++;
		}
        else if (s.find("exit") != s.npos)
		{
			if(f)
			{
				cout<<"\nPress any key to continue. . .";getch();exit(0);
			}
			else
			{
				exit(0);
			}
		}
		else if(s.find("fflush")!=s.npos)
		{
			fflush(stdin);
    		fflush(stdout);
    		cin.clear();
    		cout.clear();
    		cin.sync();
    		cur++;
		} 
        else {
            eval::Expression(s);
            cur++;
        }
    }
    void run(string s) {
        lines.clear();
        jmp.clear();
        stringstream ss; ss << s;
        string str;
        while (getline(ss, str)) {
            clear(str);
            if (str.length() > 0)lines.push_back(str);
        }
        cal_jmp();//������ת
        cur = 0;
        while (cur < lines.size()) {
            //cout << "lines : " << cur << endl;
            parser(lines[cur]);
        }
    }
    void cal_jmp() {
        stack<pair<string, int>>stk;
        for (int i = 0; i < lines.size(); i++) {
            if (count(lines[i].begin(), lines[i].end(), '{')) {
                if (lines[i].find("while") != lines[i].npos) {
                    stk.push({ "while",i });
                }
                else {
                    stk.push({ "if",i });
                }
            }
            if (count(lines[i].begin(), lines[i].end(), '}')) {
                if (stk.top().first == "if") {
                    jmp[stk.top().second] = i + 1;
                    jmp[i] = i + 1;
                }
                else {
                    jmp[stk.top().second] = i + 1;
                    jmp[i] = stk.top().second;
                }
                stk.pop();
            }
        }
    }
    void parser_print(string s) {
        cout << eval::Expression(s.substr(5, s.length() - 5));
        cur++;
    }
    void parser_scanf(string s) {
        string eq; cin >> eq;
        eval::Expression(s.substr(5, s.length() - 5) + " = " + eq);
        cur++;
    }
    void parser_gets(string s)
    {
    	string eq;
    	fflush(stdin);
    	fflush(stdout);
    	cin.clear();
    	cout.clear();
    	getline(cin,eq);
    	eval::Expression(s.substr(4, s.length() - 4) + " = \"" + eq + "\"");
    	cur++;
	}
    void parser_putchar(string s) {
        int x = eval::Expression(s.substr(6, s.length() - 6)).INT_VAL;
        cout << (char)x;
        cur++;
    }

    void parser_while(string s) {
        s.pop_back();
        Val x = eval::Expression(s.substr(5, s.length() - 5));
        if (x == 1)cur++;
        else cur = jmp[cur];
    }
    void parser_if(string s) {
        s.pop_back();
        Val x = eval::Expression(s.substr(2, s.length() - 2));
        if (x == 1)cur++;
        else cur = jmp[cur];
    }
    void parser_end(string s) {
        cur = jmp[cur];
    }

    void parser_map(string s) {
        s = s.substr(3, s.length() - 3);
        clear(s);
        eval::var_mp[s].type = MAP;
        cur++;
    }
}
