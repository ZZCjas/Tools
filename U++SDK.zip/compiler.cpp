#include <iostream>
#include <sstream>
#include <fstream>
#include <conio.h> 
#include "vm.h"
using namespace std;
bool f;
int main(int argc,char *argv[])
{
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
    ifstream fin(argv[1]);
    if(!fin)
	{
		cerr<<"FATAL ERROR:Invalid file\n"; 
		throw "FATAL ERROR:Invalid file";	
	} 
	if(argc==3)
	{
		if(strcmp(argv[2],"-pause")==0)
		{
			f=1;
		}
	}
    fin.tie(0);
    stringstream ss; 
    ss.tie(0);
	ss<<fin.rdbuf();
    vm::run(ss.str());
    if(f)
    {
    	cout<<endl<<"Press any key to continue. . .";
    	getch();
    }
    return 0;
}
