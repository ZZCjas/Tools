#pragma once

typedef struct NextTickListEntry {
	int x, y, z;
	BlockType Tile;
	int Ticks;
} NextTickListEntry;
