#pragma once

#include <math.h>
#ifndef M_PI
#define M_PI 3.14159265358979
#endif

void SinTableInitialize(void);

float tsin(float x);
float tcos(float x);
