#pragma once
#include<bits/stdc++.h>
using namespace std;
#define INT 0
#define DOU 1
#define STR 2
#define MAP 3

class Val
{
public:
    int INT_VAL = 0;
    double DOU_VAL=0.0;
    char CHA_VAL=0;
    string STR_VAL;
    struct Cmp
    {
        bool operator () (Val const &a, Val const &b)const
        {
            if (a.type != b.type)return a.type < b.type;
            else {
                if (a.type == INT)return a.INT_VAL < b.INT_VAL;
                if (a.type == DOU)return a.DOU_VAL < b.DOU_VAL;
                if (a.type == STR)return a.STR_VAL < b.STR_VAL;
                else return a.MAP_VAL < b.MAP_VAL;
            }
        }
    };

    map<Val, Val, Cmp>MAP_VAL;
    int type = 0;
    void del() { INT_VAL = DOU_VAL = 0; STR_VAL.clear(), MAP_VAL.clear(); }
    Val() {}
    Val(int x) { INT_VAL = x; type = INT; }
    Val(double x) { DOU_VAL = x; type = DOU; }
    Val(string x) { STR_VAL = x; type = STR; }
    //Val(char x) { CHA_VAL = x; type = CHA; }
    Val &operator [] (Val id);
};


Val tmp;
Val& Val::operator[](Val id) {
    if (type == STR) {
        string res; res.push_back(STR_VAL[id.INT_VAL]);
        tmp = res;
        return tmp;
    }
    return MAP_VAL[id];
}
ostream& operator << (ostream & out, const Val & v) {
    if (v.type == INT)out << v.INT_VAL;
    if (v.type == DOU)out << v.DOU_VAL;
    if (v.type == STR)out << v.STR_VAL;
    //if (v.type == CHA)cout << v.CHA_VAL;
    return out;
}
Val operator + (Val a, Val b);
Val operator - (Val a, Val b);
Val operator * (Val a, Val b);
Val operator / (Val a, Val b);

Val operator + (Val a, Val b) {
    if (a.type == DOU) {
        if (b.type == INT)return a.DOU_VAL + b.INT_VAL;
        if (b.type == DOU)return a.DOU_VAL + b.DOU_VAL;
    }
    if (a.type == INT) {
        if (b.type == INT)return a.INT_VAL + b.INT_VAL;
        if (b.type == DOU)return a.INT_VAL + b.DOU_VAL;
    }
    if (a.type == STR && b.type == STR)return a.STR_VAL + b.STR_VAL;
    if (a.type == STR && b.type == INT)return a.STR_VAL + to_string(b.INT_VAL);
    if (a.type == STR && b.type == DOU)return a.STR_VAL + to_string(b.DOU_VAL);
    if (a.type == INT && b.type == STR)return to_string(a.INT_VAL) + b.STR_VAL;
    if (a.type == DOU && b.type == STR)return to_string(a.DOU_VAL) + b.STR_VAL;
}

Val operator - (Val a, Val b) {
    if (a.type == DOU) {
        if (b.type == INT)return a.DOU_VAL - b.INT_VAL;
        if (b.type == DOU)return a.DOU_VAL - b.DOU_VAL;
    }
    if (a.type == INT) {
        if (b.type == INT)return a.INT_VAL - b.INT_VAL;
        if (b.type == DOU)return a.INT_VAL - b.DOU_VAL;
    }
}

Val operator * (Val a, Val b) {
    if (a.type == DOU) {
        if (b.type == INT)return a.DOU_VAL * b.INT_VAL;
        if (b.type == DOU)return a.DOU_VAL * b.DOU_VAL;
    }
    if (a.type == INT) {
        if (b.type == INT)return a.INT_VAL * b.INT_VAL;
        if (b.type == DOU)return a.INT_VAL * b.DOU_VAL;
    }
}

Val operator / (Val a, Val b) {
    if (a.type == DOU) {
        if (b.type == INT)return a.DOU_VAL / b.INT_VAL;
        if (b.type == DOU)return a.DOU_VAL / b.DOU_VAL;
    }
    if (a.type == INT) {
        if (b.type == INT)return a.INT_VAL / b.INT_VAL;
        if (b.type == DOU)return a.INT_VAL / b.DOU_VAL;
    }
}

Val operator % (Val a, Val b) {
    return a.INT_VAL % b.INT_VAL;
}

bool operator == (Val a, Val b) {
    if (a.type == DOU) {
        if (b.type == INT)return a.DOU_VAL == b.INT_VAL;
        if (b.type == DOU)return a.DOU_VAL == b.DOU_VAL;
    }
    if (a.type == INT) {
        if (b.type == INT)return a.INT_VAL == b.INT_VAL;
        if (b.type == DOU)return a.INT_VAL == b.DOU_VAL;
    }
    if (a.type == STR && b.type == STR) {
        return a.STR_VAL == b.STR_VAL;
    }
}

bool operator  && (Val a, Val b) {
    if (a.type == DOU) {
        if (b.type == INT)return a.DOU_VAL && b.INT_VAL;
        if (b.type == DOU)return a.DOU_VAL && b.DOU_VAL;
    }
    if (a.type == INT) {
        if (b.type == INT)return a.INT_VAL && b.INT_VAL;
        if (b.type == DOU)return a.INT_VAL && b.DOU_VAL;
    }
}

bool operator  || (Val a, Val b) {
    if (a.type == DOU) {
        if (b.type == INT)return a.DOU_VAL || b.INT_VAL;
        if (b.type == DOU)return a.DOU_VAL || b.DOU_VAL;
    }
    if (a.type == INT) {
        if (b.type == INT)return a.INT_VAL || b.INT_VAL;
        if (b.type == DOU)return a.INT_VAL || b.DOU_VAL;
    }
}

bool operator  < (Val a, Val b) {
    if (a.type == DOU) {
        if (b.type == INT)return a.DOU_VAL < b.INT_VAL;
        if (b.type == DOU)return a.DOU_VAL < b.DOU_VAL;
    }
    if (a.type == INT) {
        if (b.type == INT)return a.INT_VAL < b.INT_VAL;
        if (b.type == DOU)return a.INT_VAL < b.DOU_VAL;
    }
}


bool operator  > (Val a, Val b) {
    if (a.type == DOU) {
        if (b.type == INT)return a.DOU_VAL > b.INT_VAL;
        if (b.type == DOU)return a.DOU_VAL > b.DOU_VAL;
    }
    if (a.type == INT) {
        if (b.type == INT)return a.INT_VAL > b.INT_VAL;
        if (b.type == DOU)return a.INT_VAL > b.DOU_VAL;
    }
}

bool operator  <= (Val a, Val b) {
    if (a.type == DOU) {
        if (b.type == INT)return a.DOU_VAL <= b.INT_VAL;
        if (b.type == DOU)return a.DOU_VAL <= b.DOU_VAL;
    }
    if (a.type == INT) {
        if (b.type == INT)return a.INT_VAL <= b.INT_VAL;
        if (b.type == DOU)return a.INT_VAL <= b.DOU_VAL;
    }
}


bool operator  >= (Val a, Val b) {
    if (a.type == DOU) {
        if (b.type == INT)return a.DOU_VAL >= b.INT_VAL;
        if (b.type == DOU)return a.DOU_VAL >= b.DOU_VAL;
    }
    if (a.type == INT) {
        if (b.type == INT)return a.INT_VAL >= b.INT_VAL;
        if (b.type == DOU)return a.INT_VAL >= b.DOU_VAL;
    }
}

